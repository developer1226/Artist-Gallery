import React,{useState} from "react";
import axios from 'axios'

import "./style.css"


const RegisterUser = () => {


  // define state having two parameters
  const[name,setName]=useState("")
  
  const[email,setEmail]=useState("")
  const[password,setPassword]=useState("")
  const[gender,setGender]=useState("")
  const[contact,setContact]=useState("")
  console.warn({name,email,gender,password,contact})
  
  
  const signUp=async(e)=>{
    console.log("Hi invoca")
  //e.preventDefault();
  //  //         let data={name,email,gender,password,contact}
            let datato={
                        "userEmail":email,
                        "userName":name,
                        "userPhoneNumber":contact,
                       
                        "userPassword":password,
                        "userGender":gender
          }
  //           //creating object item
  //           console.log(datato)
  //            fetch("http://localhost:8080/userslist",{

  //           method:"POST",
           
  //      headers:{

  //            ` "Content-Type":"application/JSON",
  //             "Accept":"application/JSON",
  //             },
  //             body:JSON.stringify(datato),
  //     })

  console.log(datato);
      const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(datato)
    };
    const response = await axios.post('http://localhost:9999/userslist', datato)
    .then((response)=>{console.log("Registeration Successful...!",response)})
    .catch((error)=>{console.log("Registeration failed...!",error)})
    const data = await response.json();
 
      
    }


  return (
   
            <div class="container col-lg-4 offset-4  py-5">
            <form class="form-container">
     
              <h2 class="card-title">User Registration</h2>
                <div class="form-group py-1">
                    <label class="size">Name</label>
                        <input type="text"  value={name} onChange={(event)=>setName(event.target.value)} class="form-control line height 1" name="name" placeholder="your name" />
               </div>
              
               <div class="form-group py-1">
               
               <label>Email</label>

                        <input type="email"  value={email} name="email"onChange={(event)=>setEmail(event.target.value)} class="form-control" placeholder=" email" />
                </div>

                <div class="form-group py-1">
                 <label>Password</label>
                        <input type="password"  value={password} name="password" onChange={(event)=>setPassword(event.target.value)}class="form-control" placeholder=" Password" />
                       </div>
                       <div class="form-group py-1">
                        <label>gender</label>
                        <input type="text" value={gender}   name="gender"onChange={(event)=>setGender(event.target.value)} class="form-control" placeholder=" gender" />
                        </div>
                       
                        <div class="form-group py-1">
                 <label>Contact</label>   
                        <input type="text" value={contact}  name="contact" onChange={(event)=>setContact(event.target.value)}class="form-control" placeholder=" contact" />
                  </div>

                  <div class="form-group py-1">
                   
                        <button type="submit" onClick={()=>signUp()} class="btn btn-primary">Sign Up</button>
                  </div>
                  
            </form>
   </div>
  )
}

export default RegisterUser

// const appStyle = {
//     height: '400px',
//     display: 'flex'
// };

// const formStyle = {
//     margin: 'auto',
//     padding: '10px',
//     border: '1px solid #c9c9c9',
//     borderRadius: '5px',
//     background: '#f5f5f5',
//     width: '420px',
//     display: 'block'
// };

// const labelStyle = {
//     margin: '10px 0 5px 0',
//     fontFamily: 'Arial, Helvetica, sans-serif',
//     fontSize: '15px',
// };

// const inputStyle = {
//     margin: '5px 0 10px 0',
//     padding: '5px', 
//     border: '1px solid #bfbfbf',
//     borderRadius: '3px',
//     boxSizing: 'border-box',
//     width: '100%'
// };

// const submitStyle = {
//     margin: '10px 0 0 0',
//     padding: '7px 10px',
//     border: '1px solid #efffff',
//     borderRadius: '3px',
//     background: '#3085d6',
//     width: '100%', 
//     fontSize: '15px',
//     color: 'white',
//     display: 'block'
// };

// const Field = React.forwardRef(({label, type}, ref) => {
//     return (
//       <div>
//         <label style={labelStyle} >{label}</label>
//         <input ref={ref} type={type} style={inputStyle} />
//       </div>
//     );
// });

// const Form = ({onSubmit}) => {
//     const usernameRef = React.useRef();
//     const passwordRef = React.useRef();
//     const emailRef = React.useRef();
//     const dateofbirthRef = React.useRef();
//     const contactRef = React.useRef();
//     const addressRef = React.useRef();
//     const termsandconditionsRef = React.useRef();
//     const handleSubmit = e => {
//         e.preventDefault();
//         const data = {
//             username: usernameRef.current.value,
//             password: passwordRef.current.value,
//             email: emailRef.current.value,
//             dateofbirth: dateofbirthRef.current.value,
//             contact: contactRef.current.value,
//             address: addressRef.current.value,
//             termsandconditions: termsandconditionsRef.current.value
//         };
//         onSubmit(data);
//     };
//     return (
//       <form style={formStyle} onSubmit={handleSubmit} >
//         <Field ref={usernameRef} label="Username:" type="text" />
//         <Field ref={passwordRef} label="Password:" type="password" />
//         <Field ref={emailRef} label="Email:" type="email" />
//         <Field ref={dateofbirthRef} label="Date of Birth:" type="date" />
//         <Field ref={contactRef} label="Contact:" type="contact" />
//         <Field ref={addressRef} label="Address:" type="address" />
//         <Field ref={termsandconditionsRef} label="Terms and Conditions:" type="checkbox" />
        
//         <div>
//           <button style={submitStyle} type="submit">Submit</button>
//         </div>
//       </form>
//     );
// };

// const RegisterUser = () => {
// 	const handleSubmit = data => {
//         const json = JSON.stringify(data, null, 4);
//         console.clear();
//         console.log(json);
//     };
// 	return(
// 		<> 
// 			 <div style={appStyle}>
//         <Form onSubmit={handleSubmit} />
//       </div>
// 	  </>
// 	)
// };

// export default RegisterUser;
