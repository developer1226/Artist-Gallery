import React from 'react'
import img1 from './../Images/singer-category.jpg'
import img2 from './../Images/magician.jpg'
import img3 from './../Images/Instument.jpg'
import img4 from './../Images/anchors.jpg'
import img5 from './../Images/poety.jpg'
import img6 from './../Images/dj.jpg'
import img7 from './../Images/Dance-category.jpg'
import img8 from './../Images/comedians.jpg'
import img9 from './../Images/other.jpg'
import { Link } from 'react-router-dom'


const Categories = () => {

  


    
    return (
        <>
            
 <div class="container">
   <form>
   
    <div class="row align-center offset-1 ">
      <p class="post-head-title">CATEGORIES</p>
       
      <p class="post-head-text">
       <span class="post-head-title" >Hi User </span>Explore the wide range 
       of Entertainers and go through their profiles and testimonials. 
       Click the 'Book' button on Artist's Profile and fill in your budget and other
        details about your Event.
      </p>
    </div>
   
    <div class="row align-center  offset-1 ">
     <div class="col-md-3 col-lg-4 col-xl-3 mb-4 post-item">
         <div>
         <Link to="/singerlist" >
            <img src={img1}  class="post-img"/></Link>
         </div>
         <div class="post-title">
           <span>SINGER</span>
         </div>
       <div class="post-icon">
         <i class="fas fa-music"></i>
       </div>
     </div>
     <div class="col-md-3 col-lg-4 col-xl-3 mb-4 post-item">
       <div>
          <img src={img2} class="post-img" onClick="showByCategory()" />
       </div>
       <div class="post-title">
         <span>MAGICIAN</span>
       </div>
       <div class="post-icon">
         <i class="fas fa-hat-wizard"></i>
       </div>
     </div>
     <div class="col-md-3 col-lg-4 col-xl-3 mb-4 post-item">
       <div>
           <img src={img3} class="post-img"  onClick="showByCategory()"/>
       </div>
       <div class="post-title">
           <span>INSTRUMENTALIST</span>
       </div>
       <div class="post-icon">
           <i class="fas fa-guitar"></i>
       </div>
     </div>
   </div>

  

   <div class="row align-center offset-1">
     <div class="col-md-3 col-lg-4 col-xl-3 mb-4 post-item">
         <div>
            <img src={img4}  onClick="showByCategory()" class="post-img"/>
         </div>
         <div class="post-title">
           <span>ANCHOR/EMCC</span>
         </div>
       <div class="post-icon">
         <i class="fas fa-microphone"></i>
       </div>
     </div>
     <div class="col-md-3 col-lg-4 col-xl-3 mb-4 post-item">
       <div>
          <img src={img6}  onClick="showByCategory()" class="post-img"/>
       </div>
       <div class="post-title">
         <span>DJ</span>
       </div>
       <div class="post-icon">
         <i class="fas fa-headset"></i>
       </div>
     </div>
     <div class="col-md-3 col-lg-4 col-xl-3 mb-4 post-item">
       <div>
        <img src={img5}  onClick="showByCategory()" class="post-img"/>
       </div>
       <div class="post-title">
           <span>WRITER/POET</span>
       </div>
       <div class="post-icon">
           <i class="fas fa-pen-fancy"></i>
       </div>
     </div>
   </div>
   
  

     <div class="row align-center  offset-1 ">
       <div class="col-md-3 col-lg-4 col-xl-3 mb-4 post-item" >
           <div >
             <img src={img7}  ngModel="dancer" name="dancer"  value="dancer" onClick="showByCategory(dancer)" class="post-img"/>
           
            </div>
           <div class="post-title">
             <a  >DANCER</a>
           </div>
         <div class="post-icon">
           <i class="fas fa-child"></i>
         </div>
       </div>
       <div class="col-md-3 col-lg-4 col-xl-3 mb-4 post-item">
         <div>
            <img src={img8} ngModel="comedian" name="comedian"   onClick="showByCategory(comedian)" class="post-img"/>
         </div>
         <div class="post-title">
           <span>COMEDIAN</span>
         </div>
         <div class="post-icon">
           <i class="fas fa-laugh-beam"></i>
         </div>
       </div>
       <div class="col-md-3 col-lg-4 col-xl-3 mb-4 post-item">
         <div>
            <img src={img9} onClick="showByCategory()"  class="post-img"/>
         </div>
         <div class="post-title">
             <span>OTHER</span>
         </div>
         <div class="post-icon">
             <i class="fas fa-angle-right"></i>
         </div>
       </div>
       </div>

</form> 
     </div>
        </>
    )
}

export default Categories
