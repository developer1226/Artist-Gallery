import React from 'react'

const Singerlist = () => {
    return (
        <div>
            <h1>hi this is singer list</h1>
        </div>
    )
}

export default Singerlist
