import React,{useState} from "react";
import { NavLink } from 'react-router-dom';

const Menu = () => {
  const [show, setShow] = useState(false);
  const [isLoggedInTrue, setIsLoggedInTrue]=useState(false)
	return(
		<> 
		<nav className="navbar navbar-expand-lg navbar-light ">
  <div className="container">
   <NavLink className="navbar-brand"NavLink to ="#" >Artist Gallery</NavLink>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" onClick={() => setShow(!show)}>
      
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className={`collapse navbar-collapse ${show ? "show": ""}`} >
      <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
        <li className="nav-item">
         <NavLink className="nav-link active" aria-current="page"NavLink to ="/">Home</NavLink>
        </li>
        
        <li className="nav-item">
         <NavLink className="nav-link"NavLink to ="/categories">Categories</NavLink>
        </li>

        {!isLoggedInTrue?    <li className="nav-item dropdown">
       <NavLink className={`nav-link dropdown-toggle ${show ? "show":""}`} NavLink to ="/login" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Login
        </NavLink>
        <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><NavLink className="dropdown-item"NavLink to ="/user_login">User Login</NavLink></li>
            <li><NavLink className="dropdown-item"NavLink to ="/artist_login">Artist Login</NavLink></li>
          </ul>
      
      </li>:null}
         {/* <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Login
         </a>
          <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a className="dropdown-item" NavLink to="/user_login">User Login</a></li>
            <li><a className="dropdown-item" NavLink to="/artist_login">Artist Login</a></li>
          </ul>
        </li> */}

{!isLoggedInTrue?  <li className="nav-item dropdown">
         <NavLink className="nav-link dropdown-toggle"NavLink to ="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Sign Up
         </NavLink>
      <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><NavLink className="dropdown-item"NavLink to ="/register_user">User Registeration</NavLink></li>
            
            <li><NavLink className="dropdown-item"NavLink to ="/register_artist">Artist Registeration</NavLink></li>
          </ul>  
        </li>:null} 

        {isLoggedInTrue?   <li className="nav-item dropdown">
         <NavLink className="nav-link dropdown-toggle"NavLink to ="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Kiran
         </NavLink>
          <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><NavLink className="dropdown-item"NavLink to ="/register_user">My Profile</NavLink></li>
            
            <li><NavLink className="dropdown-item"NavLink to ="/register_artist">My orders</NavLink></li>
          </ul>
        </li>:null}
        
        
      </ul>
      {/* <form className="d-flex">
        <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search"/>
        <button className="btn btn-outline-success" type="submit">Search</button>
      </form> */}
    </div>
  </div>
</nav>  
		
			{/* <NavLink classNameName="active_className"NavLink to="/" >Home </NavLink>
			<NavLink to ="/about" >about </NavLink>
			<NavLink to ="/contact" >contact </NavLink>
			<NavLink to ="/user_login" >User Login </NavLink>
			<NavLink to ="/artist_login" >Artist Login </NavLink> */}
			

		</>
	); 
};

export default Menu;

