import React,{useState}from 'react'
import axios from 'axios'

const RegisterArtist = () => {


  const[name,setName]=useState("")
  const[genre,setGenre]=useState("")
  const[address,setAddress]=useState("")
  const[gender,setGender]=useState("")
  const[email,setEmail]=useState("")
  const[password,setPassword]=useState("")
  const[contact,setContact]=useState("")

  console.warn({name,email,gender,password,contact,genre,address})


  const signUp=async(e)=>{
    console.log("Hi invoca")
          let datato={
                        "artistEmailID":name,
                        "artistName":email,
                        "artistPassword":password,
                        "artistPhoneNumber":contact,
                        "artistGender":gender,
                        "artistGenre":genre,
                        "artistAddress":address
                      }
 
  console.log(datato);
      const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(datato)
    };
    const response = await axios.post('http://localhost:9999/artistslist', datato);
    const data = await response.json();
 
      
    }

  
  return (
    <>
      <div class="container col-lg-4 offset-4  py-5">
            <form class="form-container">
     
              <h2 class="card-title">Artist Registration</h2>
                 <div class="form-group py-1">
                          <label class="size">Name</label>
                          <input type="text" value={name} onChange={(event)=>setName(event.target.value)} class="form-control line height 1"  placeholder=" name" />
                </div>
              
                  <div class="form-group py-1">
                            <label>Email</label>
                            <input type="email" value={email} onChange={(event)=>setEmail(event.target.value)} class="form-control" placeholder=" email" />
                  </div>

                <div class="form-group py-1">
                              <label>Password</label>
                              <input type="password" value={password} onChange={(event)=>setPassword(event.target.value)}class="form-control" placeholder=" Password" />
                </div>
                      
                      
                <div class="form-group py-1">
                                <label>Genre</label>
                                <input type="text" value={genre} onChange={(event)=>setGenre(event.target.value)} class="form-control" placeholder=" genre" />
                </div>

                <div class="form-group py-1">
                                <label>Address</label>
                                <input type="text" value={address} onChange={(event)=>setAddress(event.target.value)} class="form-control" placeholder=" address" />
                </div>

                <div class="form-group py-1">
                                <label>Gender</label>
                                <input type="text" value={gender} onChange={(event)=>setGender(event.target.value)} class="form-control" placeholder=" gendre" />
                </div>
                       
                <div class="form-group py-1">
                              <label>Contact</label>   
                               <input type="text" value={contact} onChange={(event)=>setContact(event.target.value)}class="form-control" placeholder=" contact" />
                  </div>

                  
                  <div class="form-group py-1">
                   
                        <button onClick={()=>signUp()}class="btn btn-primary">Sign Up</button>
                  </div>
                  
            </form>
   </div>
    </>
  )
}

export default RegisterArtist