import React,{useState}from 'react'
import { NavLink } from 'react-router-dom';


const UserLogin = () => {

  
  const[email,setEmail]=useState("")
  const[password,setPassword]=useState("")
  
  const[flag,setFlag]=useState(false)

  

  async function Inn(){

    alert("successful login")
    let item={email,password}
    //creating object item
    console.warn(item)
    let result =await fetch("http://localhost:9999/Ulogin",{

    method:"POST",
    body:JSON.stringify(item),
    headers:{

      "Content-Type":"application/JSON",
      "Accept":"application/JSON",
     
    }
    })

      result=await result.json()
      console.warn("result",result)


  }

  return (
    <>
      <div class="container col-lg-4 offset-4  py-5">
            <form class="form-container">
              <h2 class="card-title">User Login</h2>
               <div class="form-group py-1">
                      <label>Email</label>
                      <input type="email"  onChange={(event)=>setEmail(event.target.value)} class="form-control" placeholder=" email" />
                </div>

                <div class="form-group py-1">
                      <label>Password</label>
                      <input type="password"  onChange={(event)=>setPassword(event.target.value)}class="form-control" placeholder=" Password" />
                </div>
                <div className="inputBx">
              <p>Don't have an account? <NavLink to="/register_user">Sign up</NavLink></p>
            </div>
                       
                <div class="form-group py-1">
                   
                         <button onClick={()=>Inn()}class="btn btn-primary">Login</button>
                </div>
                  
            </form>
    </div>
    </>
  )
}

export default UserLogin

