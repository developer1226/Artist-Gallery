import React from "react"
import {BrowserRouter as Router,Route,Switch} from "react-router-dom"
import Menu from "./component/Menu"
import Home from "./component/Home"
import About from "./component/About"
import Contact from "./component/Contact"
import UserLogin from "./component/UserLogin"
import RegisterUser from "./component/RegisterUser"
import ArtistLogin from "./component/ArtistLogin"
import RegisterArtist from "./component/RegisterArtist"
import "./component/Menu.css"
import Categories from "./component/Categories"
import './component/Home.css'
import './component/Categories.css'
import sidebar from "./component/sidebar"
import Singerlist from "./component/Singerlist"



// import './App.css'

function App() {
  return (
    <>
     
    <Router>
    <Menu/>
      <Switch>
     
        <Route exact path="/" component={Home} />
        <Route exact path="/about" component={About} />
        <Route exact path="/contact" component={Contact} />
        <Route exact path="/user_login" component={UserLogin} />
        <Route exact path="/register_user" component={RegisterUser} />
        <Route exact path="/artist_login" component={ArtistLogin} />
        <Route exact path="/register_artist" component={RegisterArtist} />
        <Route exact path="/categories" component={Categories} />
        <Route exact path="/categories" component={sidebar} />
        <Route exact path="/singerlist" component={Singerlist} />
        {/* <Route exact path="/login" component={Login} /> */}
      </Switch>
      </Router>
    </>
  );
}

export default App;
