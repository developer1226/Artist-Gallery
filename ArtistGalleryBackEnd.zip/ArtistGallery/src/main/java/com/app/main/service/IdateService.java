package com.app.main.service;



public interface IdateService {
	void addArtistDate(String fromdate,String todate,int fees,String email);

}
