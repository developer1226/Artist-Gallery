package com.app.main.dto;

import java.io.Serializable;


import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private String userEmail;
	
	private String userName;
	private long userPhoneNumber;
	//private String userAdddress;
	private String userPassword;
	//private String userDob;
	//private String typeOfUser;
	private String userGender;

	public User() {
		super();
	}

	public User(String userEmail, String userName, long userPhoneNumber, String userPassword, String userGender) 
	{
		super();
		this.userEmail = userEmail;
		this.userName = userName;
		this.userPhoneNumber = userPhoneNumber;
		//this.userAdddress = userAdddress;
		this.userPassword = userPassword;
		//this.userDob = userDob;
		//this.typeOfUser = typeOfUser;
		this.userGender = userGender;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public long getUserPhoneNumber() {
		return userPhoneNumber;
	}

	public void setUserPhoneNumber(long userPhoneNumber) {
		this.userPhoneNumber = userPhoneNumber;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUserGender() {
		return userGender;
	}

	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}

	@Override
	public String toString() {
		return "User [userEmail=" + userEmail + ", userName=" + userName + ", userPhoneNumber=" + userPhoneNumber
				+  ", userPassword=" + userPassword +", userGender=" + userGender + "]";
	}

}
